<?php
/**
 * Default product hover template
 *
 * @package iwp
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Direct access not allowed.
}

?>

<?php meta_theme_thumbnail_product_item() ?>



