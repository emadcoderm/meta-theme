// // Menu Overlay
(function($) {
    'use strict';
    jQuery(document).ready(function($) {
        	$(".xts-header-cats").hover(function(){
      		$(".xts-close-side").toggleClass("xts-blur-opened");
  			});
    });
})(jQuery);


// // Products Tooltip
(function($) {
    "use strict";
jQuery(document).ready(function($) {
    $(".sit-preview").smartImageTooltip({ previewTemplate: "envato", imageWidth: "500px" });
});
})(jQuery);


(function($) {
    'use strict';

    jQuery(document).ready(function($) {

        $(document).on('click', 'ul.wcdlar_download_list li a.title', function(event) {
            event.preventDefault();
            $(this).parent().toggleClass('active');
            $(this).next('.sub_items').slideToggle(300);
        });

    });
})(jQuery);


// // Lesson element
(function($) {
    'use strict';

    jQuery(document).ready(function($) {

        $(document).on('click', 'h5.course-section-title.cursor-pointer', function(event) {
            event.preventDefault();
            $(this).parent().toggleClass('active');
            $(this).next('.panel-group').slideToggle(300);
            
        });

        $(document).on('click', '.view-lessons', function(event) {
            event.preventDefault();
            $('.lessons_tab_tab').addClass('active');
            $('.description_tab').removeClass('active');
            $('.additional_information_tab').removeClass('active');
            $(".woocommerce-Tabs-panel--lessons_tab").show();
            $(".woocommerce-Tabs-panel--description").hide();
            $(".woocommerce-Tabs-panel--additional_information").hide();

        });

        $(document).on('click', '.view-desc', function(event) {
            event.preventDefault();
            $('.lessons_tab_tab').removeClass('active');
            $('.description_tab').addClass('active');
            $('.additional_information_tab').removeClass('active');
            $('.additional_lessons_tab').removeClass('active');
            $(".woocommerce-Tabs-panel--description").show();
            $(".woocommerce-Tabs-panel--lessons_tab").hide();
            $(".woocommerce-Tabs-panel--additional_information").hide();
        });


        $(".view-lessons").click(function() {
            $('html, body').animate({
              scrollTop: $(".woocommerce-tabs").offset().top - 140
            }, 1000);
          });

    });
})(jQuery);


(function($) {
    'use strict';

    jQuery(document).ready(function($) {

        $(document).on('click', '.course-section-title-elementory.cursor-pointer', function(event) {
            event.preventDefault();
            $(this).parent().toggleClass('active');
            $(this).next('.panel-group').slideToggle(300);
        });

        $(document).on('click', '.notif-row', function(event) {
            event.preventDefault();
            $(this).parent().toggleClass('active');
            $(this).next('.notif-content').slideToggle(300);
        });
			
			var acc = document.getElementsByClassName("course-panel-heading");
                var i;

                for (i = 0; i < acc.length; i++) {
                    acc[i].addEventListener("click", function() {
                        this.classList.toggle("active");
                        var panel = this.nextElementSibling;
                        if (panel.style.maxHeight){
                            panel.style.maxHeight = null;
                        } else {
                            panel.style.maxHeight = panel.scrollHeight + "px";
                        }
                    });
                }

    });
})(jQuery);



// // Preview Ajax Popup
(function($) {
    'use strict';
jQuery(document).ready(function($) {

	$('.panel-heading-right a.preview-button').click(function(event){
		event.preventDefault();
		var post_id = $(this).attr('data-lesson-id');
		var url = $(this).attr('href');

		$('.video_popup_wrrapper').fadeIn();
		$('body').find('.video_popup_wrrapper .video_popup_inner');

		$.ajax({
    type: 'post',
    url:woocommerce_params['ajax_url'],
    data:{'action':'get_lesson_video_ajax','post_id':post_id,'url':url},

   success:function (response) {
      $('body').find('.video_popup_wrrapper .video_popup_inner').html('<video controls="" autoplay="" name="media"><source src="'+response+'" type="video/mp4"></video>');
	   $('.video_popup_wrrapper').fadeIn();
   }


});
});
	$('.video_popup_overlay').click(function(event){
		$('.video_popup_wrrapper').fadeOut();
		$('body').find('.video_popup_wrrapper .video_popup_inner video').remove();
	});


    $('.box_download span').on('click', function(){
        $('.box_download .box_content').slideToggle(400);
});

$('a.link-not').on('click', function(){
        $('.collapse').slideToggle(400);
});

});
})(jQuery);
