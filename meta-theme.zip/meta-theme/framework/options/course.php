<?php
/**
 * Course Options
 *
 * @package iwp
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Direct access not allowed.
}

use XTS\Framework\Options;


Options::add_field(
	array(
		'id'          => 'course_on_off',
		'name'        => esc_html__( 'جلسات دوره', 'meta-theme' ),
		'description' => esc_html__( 'می توانید بخش جلسات دوره ها را در پیشخوان توسط این گزینه فعال و یا غیر فعال کنید', 'meta-theme' ),
		'group'       => esc_html__( 'جلسات دوره', 'meta-theme' ),
		'type'        => 'switcher',
		'section'     => 'course_section',
        'default'     => '1',
		'priority'    => 10,
	)
);

Options::add_field(
	array(
		'id'          => 'teacher_on_off',
		'name'        => esc_html__( 'اساتید', 'meta-theme' ),
		'description' => esc_html__( 'می توانید بخش اساتید را در پیشخوان فعال و یا غیر فعال کنید', 'meta-theme' ),
		'group'       => esc_html__( 'اساتید', 'meta-theme' ),
		'type'        => 'switcher',
		'section'     => 'course_section',
        'default'     => '10',
		'priority'    => 11,
	)
);

Options::add_field(
	array(
		'id'           => 'teacher_page',
		'name'         => esc_html__( 'صفحه آرشیو اساتید', 'meta-theme' ),
		'description'  => esc_html__( 'ضروری است که یک برگه خالی بسازید و اینجا به عنوان برگه آرشیو اساتید انتخاب کنید', 'meta-theme' ),
		'group'       => esc_html__( 'اساتید', 'meta-theme' ),
		'section'      => 'course_section',
		'type'         => 'select',
		'empty_option' => true,
		'select2'      => true,
		'options'      => xts_get_pages_array(),
		'priority'     => 12,
	)
);


Options::add_field(
	array(
		'id'                  => 'teacher_columns',
		'name'                => esc_html__( 'Columns', 'meta-theme' ),
		'description'         => esc_html__( 'How many projects you want to show per row.', 'meta-theme' ),
		'group'               => esc_html__( 'اساتید', 'meta-theme' ),
		'type'                => 'buttons',
		'section'             => 'course_section',
		'responsive'          => true,
		'responsive_variants' => array( 'desktop', 'tablet', 'mobile' ),
		'desktop_only'        => true,
		'options'             => array(
			2 => array(
				'name'  => 2,
				'value' => 2,
			),
			3 => array(
				'name'  => 3,
				'value' => 3,
			),
			4 => array(
				'name'  => 4,
				'value' => 4,
			),
			5 => array(
				'name'  => 5,
				'value' => 5,
			),
			6 => array(
				'name'  => 6,
				'value' => 6,
			),
		),
		'default'             => 3,
		'priority'            => 40,
	)
);

Options::add_field(
	array(
		'id'                  => 'teacher_columns_tablet',
		'name'                => esc_html__( 'Columns (tablet)', 'meta-theme' ),
		'description'         => esc_html__( 'How many projects you want to show per row.', 'meta-theme' ),
		'group'               => esc_html__( 'اساتید', 'meta-theme' ),
		'type'                => 'buttons',
		'section'             => 'course_section',
		'responsive'          => true,
		'responsive_variants' => array( 'desktop', 'tablet', 'mobile' ),
		'tablet_only'         => true,
		'options'             => array(
			2 => array(
				'name'  => 2,
				'value' => 2,
			),
			3 => array(
				'name'  => 3,
				'value' => 3,
			),
			4 => array(
				'name'  => 4,
				'value' => 4,
			),
			5 => array(
				'name'  => 5,
				'value' => 5,
			),
			6 => array(
				'name'  => 6,
				'value' => 6,
			),
		),
		'priority'            => 50,
	)
);

Options::add_field(
	array(
		'id'                  => 'teacher_columns_mobile',
		'name'                => esc_html__( 'Columns (mobile)', 'meta-theme' ),
		'description'         => esc_html__( 'How many projects you want to show per row.', 'meta-theme' ),
		'group'               => esc_html__( 'اساتید', 'meta-theme' ),
		'type'                => 'buttons',
		'section'             => 'course_section',
		'responsive'          => true,
		'responsive_variants' => array( 'desktop', 'tablet', 'mobile' ),
		'mobile_only'         => true,
		'options'             => array(
			2 => array(
				'name'  => 2,
				'value' => 2,
			),
			3 => array(
				'name'  => 3,
				'value' => 3,
			),
			4 => array(
				'name'  => 4,
				'value' => 4,
			),
			5 => array(
				'name'  => 5,
				'value' => 5,
			),
			6 => array(
				'name'  => 6,
				'value' => 6,
			),
		),
		'priority'            => 60,
	)
);

Options::add_field(
	array(
		'id'          => 'teacher_spacing',
		'name'        => esc_html__( 'Space between projects', 'meta-theme' ),
		'description' => esc_html__( 'You can set different spacing between blocks on portfolio page.', 'meta-theme' ),
		'group'       => esc_html__( 'اساتید', 'meta-theme' ),
		'type'        => 'buttons',
		'section'     => 'course_section',
		'options'     => xts_get_available_options( 'items_gap' ),
		'default'     => 10,
		'priority'    => 70,
	)
);

Options::add_field(
	array(
		'id'          => 'teacher_per_page',
		'name'        => esc_html__( 'Items per page', 'meta-theme' ),
		'description' => esc_html__( 'Number of portfolio projects that will be displayed on one page.', 'meta-theme' ),
		'group'       => esc_html__( 'اساتید', 'meta-theme' ),
		'section'     => 'course_section',
		'type'        => 'text_input',
		'default'     => 12,
		'priority'    => 80,
	)
);