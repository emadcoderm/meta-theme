<?php
/**
 * Button element template
 *
 * @package xts
 */

$params['button_link'] = array(
	'url' => $params['button_link'],
);

$params['wrapper_extra_classes'] = 'xts-header-btn';

xts_button_template( $params );
