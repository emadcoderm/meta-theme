<?php
/**
 * Root element template
 *
 * @package xts
 */

?>

<div class="xts-header-main xts-header-inner">
	<?php echo apply_filters( 'xts_header_builder_root_output', $children ); ?>
</div>
