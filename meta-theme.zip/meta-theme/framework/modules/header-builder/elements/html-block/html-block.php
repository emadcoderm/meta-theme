<?php
/**
 * HTML Block element template
 *
 * @package xts
 */

?>

<div class="xts-header-html-block">
	<?php echo xts_get_html_block_content( $params['block_id'] ); // phpcs:ignore ?>
</div>