<?php
/**
 * Social buttons element template
 *
 * @package xts
 */

$params['wrapper_extra_classes'] = 'xts-header-social';

xts_social_buttons_template( $params );
